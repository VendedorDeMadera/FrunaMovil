import { Component, OnInit } from '@angular/core';
import { NumericValueAccessor, ToastController } from '@ionic/angular';
import { NavigationExtras, Router } from '@angular/router';
import { state } from '@angular/animations';
import { NavController } from '@ionic/angular';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  login:any={
    Usuario:"",
    Contrasena:""
  }

  faltante:string="";

  constructor(public toastController: ToastController, private router:Router, private navCtrl: NavController, private apiService :ApiService ) { }

  goBack() {
    this.navCtrl.back();
  }

  ngOnInit() {
  }

  validateModel(model:any){
    for(var[key,value] of Object.entries(model)){
      if(value==""){
        this.faltante = key;
        return false;
      }
    }
    return true;
  }

  validarUsuario(dato:String){
    if(dato.length>=3 && dato.includes('@duocuc.cl')){
      return true
    }
    return false;
  }

  validarContra(dato:String){
    if(dato.length>=8 && dato.length<=15 ){
      return true
    }
    return false;
  }

  ingresar(){
    this.login.Contrasena = btoa(this.login.Contrasena);
    var varLogin = { Usuario: this.login.Usuario, Contrasena: this.login.Contrasena };
    if(this.validateModel(this.login)){
      if(this.validarUsuario(this.login.Usuario)){
        if(this.validarContra(this.login.Contrasena)){
          this.apiService.getUsuarios(this.login.Usuario).subscribe(async(user) =>{
            if(user){
              this.presentToast("Wena "+this.login.Usuario);
              let NavigationExtras:NavigationExtras={
                state:{user:this.login.Usuario}
              }
              console.log('Ingresado');
              localStorage.setItem('ingresado','true');
              localStorage.setItem('varLogin',JSON.stringify(varLogin));
              this.router.navigate(['home'],NavigationExtras);
            }
          });
        }else{
          this.presentToast("La contrasena debe tener un minimo de 8 caracteres y un maximo de 15");
          this.login.Contrasena="";
        }
      }else{
        this.presentToast("El largo del nombre de usuario debe ser un minimo de 3 e incluir @duocuc.cl");
        this.login.Usuario="";
      }
    }
    else{
      this.presentToast("Falta Rellenar El Campo de "+this.faltante);
    }
  }
  

  async presentToast(message:string, duration?:number){
    const toast = await this.toastController.create(
      {
        message:message,
        duration:duration?duration:2000
      }
    );
    toast.present();
  }
  
  
}
