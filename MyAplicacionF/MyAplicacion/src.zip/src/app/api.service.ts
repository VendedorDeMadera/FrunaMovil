import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  private apiUrl = 'http://localhost:3000/users'; // Cambia la URL según sea necesario

  constructor(private http: HttpClient) { }

  getUsuarios(Usuario: string): Observable<any> {
    return this.http.get<any[]>(this.apiUrl).pipe(
      map(users => {
        const user = users.find(u => u.email === Usuario);
        return user ? user : null;
      })
    );
  }

}
